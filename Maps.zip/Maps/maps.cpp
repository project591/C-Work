#include <iostream>
#include <string>
using namespace std;

int main()
{
    // Making the variable names generic for the final?
    string array[50];
    int age[50];
    double salary[50];
    
    string option;
       
    cout << "Enter what option you want to print: ";
    cin >> option;

    // Can the first array value serve as the table name?
    // When creating the first array value, is there a way to force someone to declare it before adding more values?

    // So from here I need to create the headers for each situation and print the values Based of Tables.

    // Idea for the Table names and the headers
    /*
    Table name String array
    string header 1
    string header 2
    string header 3
    string header 4    

    How will All this be seperated in a File? 
    */

    // Simulating user input below. User is some online store owner with many eShop websites.
    array[1] = { "Hazmat" }; // Equipment Shop Will be in different table
    array[2] = { "Hazmat" };
    array[3] = { "Gladiator" }; // DVD Online store Will be different Table
    array[4] = { "BDU" };
    array[5] = { "Hazmat" };
    array[6] = { "1023948" }; //Account Number. Will be in different table

    age[1] = { 34 };
    age[2] = { 56 };
    age[3] = { 3 };
    age[4] = { 89 }; // Amount
    age[5] = { 45 };
    age[6] = {};

    salary[1] = { 2.2 };
    salary[2] = { 24.5 };
    salary[3] = { 2.35 };
    salary[4] = { 23 }; // Price
    salary[5] = { 12 };

    // Need to make the comparisons for arrays inside a for loop.
    // In the real program, it will probably require this part to be dynamically allocated arrays.
    cout << "Customs   " << "Age      " << "Salary" << endl << endl;
    for (int i = 0; i < 50; i++) {
        // In the main program it will change to whatever the user wants it to be.
        if (array[i] == option) {
            cout << array[i] << "       " << age[i] << "       " << salary[i] << endl;
        }        
    }
    system("pause");
    return 0;
}

// Another Idea.. Could the header of the "Tables" be an array as well. They will be displayed at the top of the
// Screen.

// How are you going to show the tables. When displaying the tables names, you need to make that there are no duplicates.
// When displaying them.

// Each table should be able to display a unique header that the user has defined. 

// If the arrays are to be Dynamically created, then how will their persistence be made (write to files?)

//